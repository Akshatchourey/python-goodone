
while(True):
    a=int(input("enter the no"))
    for i in range(1,11):
        print(a,"X",i,"=",a*i)

    y=bool(input("do you want to reechack in not press enter."))
    if(y==0):
        break


print("thx")
input("press enter to exit.")
































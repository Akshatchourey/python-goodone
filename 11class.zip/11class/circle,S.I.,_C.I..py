#Program to print the commpoand intrest.
a=float(input("enter the value of investment."))
r=float(input("enter the value of intrest rate."))
t=int(input("enter the duration of tine."))
n=int(input("no of times intrest is compounded per unit time."))
p=a*(1+r/n)**(n*t)
print("the totle amount is =",p)

